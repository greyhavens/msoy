This directory contains an archive of useful tools for game development,
contributed by various authors and users of the Whirled SDK.

To use these files in your ActionScript code, modify your project's build.xml,
to add a property named "app.source-extras" pointing to this directory, e.g.

  <property name="app.source-extras" value="../../../contrib/src/as/"/>

If you would like to contribute your own code to the project, please post about
it on the Whirled Forums!

-- The Keepers of the Peas
